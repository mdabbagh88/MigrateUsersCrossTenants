
. .\Common-Classes.ps1
. .\Common-Functions.ps1

# $ErrorActionPreference = 'Continue'
# $WarningPreference = 'Continue'

$directory_unprocessed_path = $(Get-Item ".").FullName + "/data/unprocessed"
$directory_processing_path = $(Get-Item ".").FullName + "/data/processing"
$directory_processed_path = $(Get-Item ".").FullName + "/data/processed"

$date_current = Get-Date -Format "yyyy-MM-dd"
$directory_today_processing_path = "$directory_processing_path/$date_current"
$directory_today_processed_path = "$directory_processed_path/$date_current"

$time_current = Get-Date -Format "HH-mm-ss"
$file_today_processing_path = "$directory_today_processing_path/$time_current.csv"
$file_today_processed_path = "$directory_today_processed_path/$time_current.csv"

if (!(Test-Path -PathType Container $directory_today_processing_path)) { New-Item -ItemType Directory -Path $directory_today_processing_path | Out-Null }
if (!(Test-Path -PathType Container $directory_today_processed_path)) { New-Item -ItemType Directory -Path $directory_today_processed_path | Out-Null }

$security_group_name = "MigrateUsersListSecurityGroup"
$files_unprocessed = Get-ChildItem -Path $directory_unprocessed_path -filter "*.csv"

$files_unprocessed | Select-Object -ExpandProperty FullName | Import-Csv | Export-Csv $file_today_processing_path -NoTypeInformation -Append

$files_unprocessed | Remove-Item -Verbose

$files_processing = Get-ChildItem -Path $directory_today_processing_path -filter "*.csv"

foreach ($_ in $files_processing) {
	Write-Host "--------------------------------------------------------------------"
	Write-Host "Executing file => $($_.FullName)"
	Write-Host "--------------------------------------------------------------------"
	# TODO: split users into 27 source tenants
	
	$file_name = $_.Name
	$file_name_no_ext = [System.IO.Path]::GetFileNameWithoutExtension($_.FullName)
	$file_ext = $_.Extension
	$file_path = $_.FullName
	$file_path_fetched = "$file_path.fetched"
	$file_path_locked = "$file_path.locked"
	
	# Read users
	$users = Read-Users-From-CSV $file_path
	Write-Host "file $file_path contains $($user.Count) users"
	
	# if the count is 0 continue to the next file
	if ($users.count -eq 0) {
		write-host "Validation failed for users file users.count = 0"
		continue
	}

	$users_is_fetched = $false
	if ((Test-Path -Path $file_path_fetched -PathType Leaf) -eq $true) {
		$users_fetched = Read-Users-From-CSV $file_path_fetched
		$users_is_fetched = ($users.Count -eq $users_fetched.Count)
	}
	
	# Prepare user info
	if ($users_is_fetched) {
		$users = $users_fetched
	} else {
		# Group users by source tenant
		# https://learn.microsoft.com/en-us/dotnet/api/microsoft.powershell.commands.groupinfo?view=powershellsdk-7.2.0
		# Properties: Count, Name, Group
		$users_groups = $users | Sort-Object SourceTenant | Group-Object -Property SourceTenant

		foreach ($users_group in $users_groups) {
			$tenant_name = $users_group.Name
			$tenant_users = $users_group.Group
			$tenant = Get-Tenant $tenant_name
	
			# Fecth users info by source
			Import-Users-Info $tenant $tenant_users $true
		}
	
		# Save all users info
		Save-Users-To-CSV $users $file_path_fetched
	}

	# Lock users on source
	# Group users by source tenant
	# https://learn.microsoft.com/en-us/dotnet/api/microsoft.powershell.commands.groupinfo?view=powershellsdk-7.2.0
	# Properties: Count, Name, Group
	$users_groups = $users | Sort-Object SourceTenant | Group-Object -Property SourceTenant

	foreach ($users_group in $users_groups) {
		$tenant_name = $users_group.Name
		$tenant_users = $users_group.Group
		$tenant = Get-Tenant $tenant_name

		# Add source users to mail-enabled security group
		Add-Users-To-Migration $tenant $tenant_users $security_group_name
	}

	# Save mail-enabled security group migration status
	Save-Users-To-CSV $users $file_path_locked

	# MailBox Migration
	# Group users by source & target tenants
	# https://learn.microsoft.com/en-us/dotnet/api/microsoft.powershell.commands.groupinfo?view=powershellsdk-7.2.0
	# Properties: Count, Name, Group
	$users_groups = $users | Sort-Object SourceTenant | Group-Object -Property SourceTenant,TargetTenant

	foreach ($users_group in $users_groups) {
		$tenant_names = $users_group.Name.Split(',').Trim()
		$tenant_source_name = $tenant_names[0]
		$tenant_target_name = $tenant_names[1]
		$tenant_source = Get-Tenant $tenant_source_name
		$tenant_target = Get-Tenant $tenant_target_name
		$tenant_users = $users_group.Group

		# Mailbox Migration
		New-Mailbox-Migration-Batch $tenant_source $tenant_target $tenant_users
	}
	
	# Save mailbox migration status
	Save-Users-To-CSV $users $file_path_fetched

	# Groups & Licenses Migration
	# https://learn.microsoft.com/en-us/dotnet/api/microsoft.powershell.commands.groupinfo?view=powershellsdk-7.2.0
	# Properties: Count, Name, Group
	$users_groups = $users | Sort-Object TargetTenant | Group-Object -Property TargetTenant

	# Fetch users id on taregt
	foreach ($users_group in $users_groups) {
		$tenant_name = $users_group.Name
		$tenant_users = $users_group.Group
		$tenant = Get-Tenant $tenant_name

		# Fecth user info (TargetId)
		Import-Users-Info $tenant $tenant_users $false
	}
	
	# Export full user info
	Save-Users-To-CSV $users $file_path_fetched

	# Assgin users to groups
	foreach ($users_group in $users_groups) {
		$tenant_name = $users_group.Name
		$tenant_users = $users_group.Group
		$tenant = Get-Tenant $tenant_name

		# Add target users to (teacher or student group)
		Add-Users-To-Groups $tenant $tenant_users
	}
	
	# Save groups migration status
	Save-Users-To-CSV $users $file_path_fetched
	
	# # Assgin licenses to users
	# foreach ($users_group in $users_groups) {
	# 	$tenant_name = $users_group.Name
	# 	$tenant_users = $users_group.Group
	# 	$tenant = Get-Tenant $tenant_name

	# 	Assing target users groups (Done by portal inherited by groups) (raise error in script if inheritance is enabled)
	# 	Add-Licenses-To-Users $tenant $tenant_users
	# }
	
	# # Save licenses migration status
	# Save-Users-To-CSV $users $file_path_fetched

	# Disable Old Users
	# https://learn.microsoft.com/en-us/dotnet/api/microsoft.powershell.commands.groupinfo?view=powershellsdk-7.2.0
	# Properties: Count, Name, Group
	$users_groups = $users | Sort-Object SourceTenant | Group-Object -Property SourceTenant

	foreach($users_group in $users_groups) {
		$tenant_name = $users_group.Name
		$tenant_users = $users_group.Group
		$tenant = Get-Tenant $tenant_name

		# Disable Users
		Disable-Users $tenant $tenant_users
	}
		
	# Save user's status
	Save-Users-To-CSV $users $file_path_fetched

	write-host "====================================================================`n`n"
}

#Connect-ExchangeOnline -UserPrincipalName mfarag@dev1.rb.moe.gov.sa
#Get-Mailbox migrate_2_dev1
#Get-MigrationBatch -Identity $MigrationScope